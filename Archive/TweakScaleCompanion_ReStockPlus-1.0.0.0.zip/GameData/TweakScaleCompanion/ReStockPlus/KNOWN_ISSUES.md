# TweakScale Companion :: ReStock+ :: Known Issues

* Docking ports, Fairings and Ladders are not supported by this patch.
	+ It is a consistent behaviour with stock parts due to TweakScale known limits (well for docking ports it seems to be a really bad idea)
