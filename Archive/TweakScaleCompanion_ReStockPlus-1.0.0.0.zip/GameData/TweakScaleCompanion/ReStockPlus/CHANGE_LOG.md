# TweakScale Companion :: ReStockPlus :: Change Log

* 2020-0307: 1.0.0.0 (OnlyLightMatters, LisiasT) for ReStockPlus >= 1.0.3
	+ Initial Release
