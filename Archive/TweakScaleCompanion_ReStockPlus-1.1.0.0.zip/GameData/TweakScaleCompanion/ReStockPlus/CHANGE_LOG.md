# TweakScale Companion :: ReStockPlus :: Change Log

* 2020-0507: 1.1.0.0 (OnlyLightMatters, LisiasT) for ReStockPlus >= 1.0.3
	+ Added new parts brought by RS+ 1.1.0
* 2020-0307: 1.0.0.0 (OnlyLightMatters, LisiasT) for ReStockPlus >= 1.0.3
	+ Initial Release
